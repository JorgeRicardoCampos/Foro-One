package com.example.Foro_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForoApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
